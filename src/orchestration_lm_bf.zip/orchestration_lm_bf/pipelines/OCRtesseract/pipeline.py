from kedro.pipeline import Pipeline, node, pipeline
from .nodes import extract_text, get_detections

def create_pipeline(**kwargs) -> Pipeline:
    return pipeline([
        node(
            func=get_detections, 
            inputs=["model", "params:images_folder"], 
            outputs="detections", 
            name="get_detections"
            ),
        node(
            func=extract_text,
            inputs="detections",
            outputs="ocr_text",
            name="ocr_extraction_node"
        )
    ])