"""
This is a boilerplate pipeline 'evaluateModelAPI'
generated using Kedro 0.19.12
"""

from .pipeline import create_pipeline

__all__ = ["create_pipeline"]

__version__ = "0.1"
